package main

import "fmt"

func main() {
	var m map[string]bool = make(map[string]bool)
	fmt.Println(m)
}
