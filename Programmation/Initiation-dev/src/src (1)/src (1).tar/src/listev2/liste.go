/*
Package liste implements a french data-structure for list creation and manipulation.
*/
package liste
